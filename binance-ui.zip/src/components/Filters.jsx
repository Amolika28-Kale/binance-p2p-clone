
import TextField from '@mui/material/TextField'
import MenuItem from '@mui/material/MenuItem'

export default function Filters() {
  return (
    <div className="flex flex-wrap gap-4 mb-6">
      <TextField size="small" label="Amount" />
      <TextField size="small" select label="Payment">
        <MenuItem value="">All</MenuItem>
        <MenuItem value="UPI">UPI</MenuItem>
        <MenuItem value="Bank">Bank</MenuItem>
      </TextField>
      <TextField size="small" label="Search advertiser" />
    </div>
  )
}
