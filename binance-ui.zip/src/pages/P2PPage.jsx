
import BuySellTabs from '../components/BuySellTabs'
import Filters from '../components/Filters'
import AdsTable from '../components/AdsTable'

export default function P2PPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <BuySellTabs />
      <Filters />
      <AdsTable />
    </div>
  )
}
