
import P2PPage from './pages/P2PPage'

export default function App() {
  return (
    <div className="bg-[#0b0e11] min-h-screen text-[#eaecef]">
      <P2PPage />
    </div>
  )
}
