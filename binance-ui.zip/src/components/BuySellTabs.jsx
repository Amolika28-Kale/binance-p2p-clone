
import { useState } from 'react'

export default function BuySellTabs() {
  const [mode, setMode] = useState("BUY")
  return (
    <div className="flex gap-6 border-b border-border mb-4">
      {["BUY","SELL"].map(m => (
        <button key={m}
          onClick={()=>setMode(m)}
          className={mode===m ? "text-white border-b-2 border-yellow pb-2" : "text-gray-400 pb-2"}>
          {m}
        </button>
      ))}
    </div>
  )
}
