
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#0b0e11",
        card: "#1e2329",
        border: "#2b3139",
        yellow: "#fcd535",
        green: "#0ecb81"
      }
    }
  },
  plugins: [],
}
