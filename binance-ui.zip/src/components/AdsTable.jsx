
export default function AdsTable() {
  return (
    <div className="bg-card rounded-lg overflow-hidden">
      <div className="grid grid-cols-5 text-sm text-gray-400 px-4 py-2 border-b border-border">
        <div>Advertiser</div>
        <div>Price</div>
        <div>Available</div>
        <div>Payment</div>
        <div></div>
      </div>
      {[1,2,3].map(i=>(
        <div key={i} className="grid grid-cols-5 px-4 py-4 hover:bg-[#161a1e] border-b border-border">
          <div>User{i}</div>
          <div>₹92.5</div>
          <div>5000 USDT</div>
          <div>UPI</div>
          <button className="bg-green text-black px-3 py-1 rounded">Buy</button>
        </div>
      ))}
    </div>
  )
}
